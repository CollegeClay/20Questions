README
Clayton Christensen
Collaborators: None

This assignment was definetly a little challenging, but very doable. The biggest challenge I had on this project was simply getting it done. This 
week I have definetly been in the spring break minset and have had a lot of trouble focusing on school. The hardest part of doing this assignment 
was simply getting started. I would work on it in short intervals, but I would never really work on it long enough to make any substantial progress.
It was only the deadline of it being due tonight that really helped me focus up and get it done. And now its spring break!

I really liked this assignment. It allowed me to get a lot more confortable with binary trees and inputing text into a file. I feel like I have learned 
a lot and am a lot more confident that if I see a binary tree problem on the next midterm that I will be able to do it. I disliked that we had a project
the week before spring break, but that is just school so I can't complain to much.

I spent about four hours working on this assignment.
I didn't add any novel features.

PS: Hope you all have an amazing spring break!